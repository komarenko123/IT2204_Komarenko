enum CoffeeType {
  cappuccino,
  espresso,
  americano,
}