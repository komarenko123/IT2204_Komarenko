abstract class ICoffee {
  int coffeeBeans();
  int milk();        
  int water();       
  int cash();       
}